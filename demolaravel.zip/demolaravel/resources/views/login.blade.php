<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
    <title></title>
    
    <link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
    
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.4/jquery.min.js"></script>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.6/jquery-ui.min.js"></script>
    <script type="text/javascript" src="js/jquery.inputfocus-0.9.min.js"></script>
    <script type="text/javascript" src="js/jquery.main.js"></script>
</head>
<body>
 <div id="container">
        <form action="#" method="post">
    
            <!-- #first_step -->
            <div id="first_step">
                <h1>SIGN IN<span>WEBEXP18</span>ACCOUNT</h1>
                <label><a href="http://localhost/demolaravel/public">Log In</a></label>

                <div class="form">
                    <input type="text" name="username" id="" value="username" />
                    <label for="username"></label>
                    
                    <input type="password" name="password" id="" value="password" />
                    <label for="password"></label>

                    
                   
                </div>      <!-- clearfix --><div class="clear"></div><!-- /clearfix -->
                <input  style="left: 72px; width:100px; margin-left: 72px;" type="submit" name="submit_first"  value="Login" />
                <input  style="left: 77px; width:100px; margin-left: 10px;" type="submit" name="submit_first"  value="SignUp" />
                <div class="clear"></div>
                <label><a href="http://localhost/demolaravel/public/signup">Sign Up</a></label>
            </div>      <!-- clearfix --><div class="clear"></div><!-- /clearfix -->
</form>
</div>
</body>
</html>